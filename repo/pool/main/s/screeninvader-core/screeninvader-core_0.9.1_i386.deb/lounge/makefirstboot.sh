#!/bin/bash

usermod -s /setup/firstboot.sh root
reboot
